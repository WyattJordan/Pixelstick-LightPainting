// Font data for Agency FB 105pt
extern const uint_8 agencyFB_105ptBitmaps[];
extern const FONT_INFO agencyFB_105ptFontInfo;
extern const FONT_CHAR_INFO agencyFB_105ptDescriptors[];

