// Font data for Agency FB 53pt
extern const uint_8 agencyFB_53ptBitmaps[];
extern const FONT_INFO agencyFB_53ptFontInfo;
extern const FONT_CHAR_INFO agencyFB_53ptDescriptors[];

